# -*- coding: utf-8 -*-
"""
Created on Sat Dec 12 15:28:57 2020

@author: Rui Campos
"""

